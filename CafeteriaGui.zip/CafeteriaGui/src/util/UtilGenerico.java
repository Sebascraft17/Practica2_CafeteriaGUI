package util;

import java.util.ArrayList;

public class UtilGenerico {

    // Crea una lista con todos los elementos que reciba
    public static <T> ArrayList<T> crearLista(T... elementos) {
        ArrayList<T> lista = new ArrayList<>();
        for (T e : elementos) {
            lista.add(e);
        }
        return lista;
    }

    // Agrega varios elementos a una lista existente y devuelve cuántos agregó
    public static <T> int agregarVarios(ArrayList<T> lista, T... elementos) {
        for (T e : elementos) {
            lista.add(e);
        }
        return elementos.length;
    }
}