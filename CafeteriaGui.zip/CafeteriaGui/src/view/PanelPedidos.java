package view;

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import model.Cafeteria;
import model.Detalle_Pedido;
import model.Pedido;
import model.Producto;
import util.UtilGenerico;

public class PanelPedidos extends JPanel implements ActionListener {

    private Cafeteria cafeteria;
    private String fecha;
    private Pedido pedidoActual;
    private JComboBox<String> comboProductos = new JComboBox<>();
    private JTextField txtCantidad = new JTextField(5);
    private JButton btnAgregar = new JButton("Agregar");
    private JButton btnConfirmar = new JButton("Confirmar pedido");
    private JButton btnCancelar = new JButton("Cancelar pedido");
    private JLabel lblTotales = new JLabel("Subtotal: $0   IVA: $0   TOTAL: $0");
    private DefaultTableModel datos;

    public PanelPedidos(Cafeteria cafeteria, String fecha) {
        this.cafeteria = cafeteria;
        this.fecha = fecha;
        pedidoActual = new Pedido(cafeteria.siguienteNumeroPedido(), fecha);

        comboProductos.addItem("-- Seleccione un producto --");
        for (Producto p : cafeteria.getProductos()) {
            comboProductos.addItem(p.getCodigo() + " - " + p.getNombre());
        }

        ArrayList<String> columnas = new ArrayList<>();
        UtilGenerico.agregarVarios(columnas, "Producto", "Cantidad", "Subtotal");
        datos = new DefaultTableModel(columnas.toArray(), 0);
        JTable tabla = new JTable(datos);
        tabla.setEnabled(false);

        JPanel arriba = new JPanel();
        arriba.add(new JLabel("Producto:"));
        arriba.add(comboProductos);
        arriba.add(new JLabel("Cantidad:"));
        arriba.add(txtCantidad);
        arriba.add(btnAgregar);

        JPanel abajo = new JPanel();
        abajo.add(lblTotales);
        abajo.add(btnConfirmar);
        abajo.add(btnCancelar);

        setLayout(new BorderLayout());
        add(arriba, BorderLayout.NORTH);
        add(new JScrollPane(tabla), BorderLayout.CENTER);
        add(abajo, BorderLayout.SOUTH);

        btnAgregar.addActionListener(this);
        btnConfirmar.addActionListener(this);
        btnCancelar.addActionListener(this);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnAgregar) {
            agregar();
        } else if (e.getSource() == btnConfirmar) {
            confirmar();
        } else {
            nuevoPedido();
        }
    }

    private void agregar() {
        int indice = comboProductos.getSelectedIndex();
        if (indice == 0) {
            JOptionPane.showMessageDialog(this, "Seleccione un producto.");
            return;
        }
        try {
            Producto p = cafeteria.getProductos().get(indice - 1);
            int cantidad = Integer.parseInt(txtCantidad.getText().trim());
            if (pedidoActual.agregarProducto(p, cantidad)) {
                txtCantidad.setText("");
                mostrarPedido();
            } else {
                JOptionPane.showMessageDialog(this, "Cantidad no válida o stock insuficiente (disponible: " + p.getStock() + ").");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "La cantidad debe ser un número entero.");
        }
    }

    private void confirmar() {
        if (pedidoActual.getDetalles().isEmpty()) {
            JOptionPane.showMessageDialog(this, "El pedido está vacío. Agregue al menos un producto.");
            return;
        }
        try {
            cafeteria.registrarPedido(pedidoActual);
            JOptionPane.showMessageDialog(this, "Pedido N.º " + pedidoActual.getNumero()
                    + " registrado. Total a pagar: $" + pedidoActual.getTotal());
            nuevoPedido();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "No se pudo guardar el pedido.");
        }
    }

    // Empieza un pedido vacío (después de confirmar o de cancelar)
    private void nuevoPedido() {
        pedidoActual = new Pedido(cafeteria.siguienteNumeroPedido(), fecha);
        mostrarPedido();
    }

    private void mostrarPedido() {
        datos.setRowCount(0);
        for (Detalle_Pedido d : pedidoActual.getDetalles()) {
            datos.addRow(new Object[] { d.getProducto().getNombre(), d.getCantidad(), d.getSubtotal() });
        }
        lblTotales.setText("Subtotal: $" + pedidoActual.getSubtotal() + "   IVA: $" + pedidoActual.getIva()
                + "   TOTAL: $" + pedidoActual.getTotal());
    }
}