package view;

import java.awt.event.*;
import java.io.IOException;
import javax.swing.*;
import model.Cafeteria;

public class MenuPrincipal extends JFrame implements ActionListener {

    private Cafeteria cafeteria;
    private String fecha;
    private JButton btnProductos = new JButton("Productos");
    private JButton btnPedidos = new JButton("Pedidos");
    private JButton btnReportes = new JButton("Reportes");

    public MenuPrincipal(String fecha) {
        this.fecha = fecha;
        try {
            cafeteria = new Cafeteria();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "No se pudieron leer los archivos.");
            System.exit(0);
        }

        setTitle("Cafetería El Buen Sabor - Versión 2.0");
        setSize(480, 150);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.add(new JLabel("Fecha de hoy: " + fecha));
        panel.add(btnProductos);
        panel.add(btnPedidos);
        panel.add(btnReportes);
        add(panel);

        btnProductos.addActionListener(this);
        btnPedidos.addActionListener(this);
        btnReportes.addActionListener(this);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnProductos) {
            abrir("Productos", new PanelProductos(cafeteria));
        } else if (e.getSource() == btnPedidos) {
            abrir("Pedidos", new PanelPedidos(cafeteria, fecha));
        } else {
            abrir("Reportes", new PanelReportes(cafeteria, fecha));
        }
    }

    private void abrir(String titulo, JPanel panel) {
        JDialog ventana = new JDialog(this, titulo, true);
        ventana.add(panel);
        ventana.setSize(820, 420);
        ventana.setLocationRelativeTo(this);
        ventana.setVisible(true);
    }
}