package view;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import model.Cafeteria;
import model.Producto;
import util.UtilGenerico;

public class PanelReportes extends JPanel {

    public PanelReportes(Cafeteria cafeteria, String fecha) {
        DefaultTableModel datos = new DefaultTableModel(
                UtilGenerico.crearLista("Producto", "Unidades vendidas").toArray(), 0);
        for (Producto p : cafeteria.getProductos()) {
            int unidades = cafeteria.unidadesVendidas(p, fecha);
            if (unidades > 0) {
                datos.addRow(new Object[] { p.getNombre(), unidades });
            }
        }
        JTable tabla = new JTable(datos);
        tabla.setEnabled(false);

        Producto mas = cafeteria.productoMasVendido(fecha);
        String masVendido = "no hay ventas";
        if (mas != null) {
            masVendido = mas.getNombre();
        }

        setLayout(new BorderLayout());
        add(new JLabel("Total vendido el " + fecha + ": $" + cafeteria.totalVendido(fecha)
                + "   |   Producto más vendido: " + masVendido), BorderLayout.NORTH);
        add(new JScrollPane(tabla), BorderLayout.CENTER);
    }
}