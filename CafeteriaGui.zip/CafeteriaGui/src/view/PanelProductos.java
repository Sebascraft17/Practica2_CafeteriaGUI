package view;

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import model.Cafeteria;
import model.Producto;
import util.UtilGenerico;

public class PanelProductos extends JPanel implements ActionListener {

    private Cafeteria cafeteria;
    private JTextField txtCodigo = new JTextField(6);
    private JTextField txtNombre = new JTextField(8);
    private JTextField txtPrecio = new JTextField(6);
    private JTextField txtStock = new JTextField(6);
    private JButton btnRegistrar = new JButton("Registrar");
    private JButton btnEditar = new JButton("Editar");
    private JButton btnReponer = new JButton("Reponer stock");
    private DefaultTableModel datos = new DefaultTableModel(
            UtilGenerico.crearLista("Código", "Nombre", "Precio", "Stock").toArray(), 0);

    public PanelProductos(Cafeteria cafeteria) {
        this.cafeteria = cafeteria;
        JTable tabla = new JTable(datos);
        tabla.setEnabled(false);

        JPanel formulario = new JPanel();
        formulario.add(new JLabel("Código:"));
        formulario.add(txtCodigo);
        formulario.add(new JLabel("Nombre:"));
        formulario.add(txtNombre);
        formulario.add(new JLabel("Precio:"));
        formulario.add(txtPrecio);
        formulario.add(new JLabel("Stock:"));
        formulario.add(txtStock);
        formulario.add(btnRegistrar);
        formulario.add(btnEditar);
        formulario.add(btnReponer);

        setLayout(new BorderLayout());
        add(formulario, BorderLayout.NORTH);
        add(new JScrollPane(tabla), BorderLayout.CENTER);

        btnRegistrar.addActionListener(this);
        btnEditar.addActionListener(this);
        btnReponer.addActionListener(this);
        actualizar();
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnRegistrar) {
            registrar();
        } else if (e.getSource() == btnEditar) {
            editar();
        } else {
            reponer();
        }
    }

    private void registrar() {
        String codigo = txtCodigo.getText().trim().toUpperCase().replace(" ", "");
        String nombre = txtNombre.getText().trim().replace(" ", "_");
        if (codigo.equals("") || nombre.equals("")) {
            JOptionPane.showMessageDialog(this, "Escriba el código y el nombre.");
            return;
        }
        try {
            double precio = Double.parseDouble(txtPrecio.getText().trim());
            int stock = Integer.parseInt(txtStock.getText().trim());
            if (precio <= 0 || stock < 0) {
                JOptionPane.showMessageDialog(this, "El precio debe ser mayor a 0 y el stock no puede ser negativo.");
            } else if (cafeteria.registrarProducto(new Producto(codigo, nombre, precio, stock))) {
                JOptionPane.showMessageDialog(this, "Producto registrado.");
                actualizar();
            } else {
                JOptionPane.showMessageDialog(this, "Ya existe un producto con ese código.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "El precio y el stock deben ser números (decimales con punto).");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "No se pudo guardar el archivo.");
        }
    }

    // Cambia el nombre y el precio del producto con ese código
    private void editar() {
        String codigo = txtCodigo.getText().trim().toUpperCase().replace(" ", "");
        String nombre = txtNombre.getText().trim().replace(" ", "_");
        if (codigo.equals("") || nombre.equals("")) {
            JOptionPane.showMessageDialog(this, "Escriba el código, el nuevo nombre y el nuevo precio.");
            return;
        }
        try {
            double precio = Double.parseDouble(txtPrecio.getText().trim());
            if (precio <= 0) {
                JOptionPane.showMessageDialog(this, "El precio debe ser mayor a 0.");
            } else if (cafeteria.editarProducto(codigo, nombre, precio)) {
                JOptionPane.showMessageDialog(this, "Producto actualizado.");
                actualizar();
            } else {
                JOptionPane.showMessageDialog(this, "No existe un producto con ese código.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "El precio debe ser un número (decimales con punto).");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "No se pudo guardar el archivo.");
        }
    }

    private void reponer() {
        String codigo = txtCodigo.getText().trim().toUpperCase().replace(" ", "");
        if (cafeteria.buscarProducto(codigo) == null) {
            JOptionPane.showMessageDialog(this, "Escriba el código de un producto que exista.");
            return;
        }
        String texto = JOptionPane.showInputDialog(this, "Cantidad a reponer:");
        if (texto == null) {
            return;   // canceló
        }
        try {
            int cantidad = Integer.parseInt(texto.trim());
            if (cantidad <= 0) {
                JOptionPane.showMessageDialog(this, "La cantidad debe ser mayor a 0.");
            } else {
                cafeteria.reponerStock(codigo, cantidad);
                JOptionPane.showMessageDialog(this, "Stock actualizado.");
                actualizar();
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "La cantidad debe ser un número entero.");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "No se pudo guardar el archivo.");
        }
    }

    // Limpia los campos y vuelve a llenar la tabla
    private void actualizar() {
        txtCodigo.setText("");
        txtNombre.setText("");
        txtPrecio.setText("");
        txtStock.setText("");
        datos.setRowCount(0);
        for (Producto p : cafeteria.getProductos()) {
            datos.addRow(new Object[] { p.getCodigo(), p.getNombre(), p.getPrecio(), p.getStock() });
        }
    }
}