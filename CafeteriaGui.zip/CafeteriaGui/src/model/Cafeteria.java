package model;

import java.io.IOException;
import java.util.ArrayList;

public class Cafeteria {

    private ArrayList<Producto> productos;
    private ArrayList<Pedido> pedidos;
    private ArchivoDatos archivos;

    public Cafeteria() throws IOException {
        archivos = new ArchivoDatos();
        productos = archivos.cargarProductos();
        pedidos = archivos.cargarPedidos(productos);
    }

    // GETTER NECESARIO PARA LAS VISTAS
    public ArrayList<Producto> getProductos() {
        return productos;
    }

    public Producto buscarProducto(String codigo) {
        for (Producto p : productos) {
            if (p.getCodigo().equals(codigo)) {
                return p;
            }
        }
        return null;
    }

    public boolean registrarProducto(Producto producto) throws IOException {
        if (buscarProducto(producto.getCodigo()) != null) {
            return false;
        }
        productos.add(producto);
        archivos.guardarProductos(productos);
        return true;
    }

    // MÉTODO AGREGADO PARA PANELPRODUCTOS
    public boolean editarProducto(String codigo, String nuevoNombre, double nuevoPrecio) throws IOException {
        Producto p = buscarProducto(codigo);
        if (p == null) {
            return false;
        }
        p.setNombre(nuevoNombre);
        p.setPrecio(nuevoPrecio);
        archivos.guardarProductos(productos);
        return true;
    }

    public void listarProductos() {
        if (productos.isEmpty()) {
            System.out.println("El catálogo está vacío.");
        }
        for (Producto p : productos) {
            System.out.println(p.getCodigo() + " | " + p.getNombre() + " | $" + p.getPrecio() + " | Stock: " + p.getStock());
        }
    }

    public boolean reponerStock(String codigo, int cantidad) throws IOException {
        Producto p = buscarProducto(codigo);
        if (p == null) {
            return false;
        }
        p.aumentarStock(cantidad);
        archivos.guardarProductos(productos);
        return true;
    }

    public int siguienteNumeroPedido() {
        return pedidos.size() + 1;
    }

    public void registrarPedido(Pedido pedido) throws IOException {
        pedidos.add(pedido);
        archivos.guardarProductos(productos);
        archivos.guardarPedidos(pedidos);
    }

    // MÉTODO CAMBIADO A PUBLIC PARA PANELREPORTES
    public int unidadesVendidas(Producto producto, String fecha) {
        int unidades = 0;
        for (Pedido p : pedidos) {
            if (p.getFecha().equals(fecha)) {
                for (Detalle_Pedido d : p.getDetalles()) {
                    if (d.getProducto().getCodigo().equals(producto.getCodigo())) {
                        unidades = unidades + d.getCantidad();
                    }
                }
            }
        }
        return unidades;
    }

    // MÉTODO AGREGADO PARA PANELREPORTES
    public double totalVendido(String fecha) {
        double total = 0;
        for (Pedido p : pedidos) {
            if (p.getFecha().equals(fecha)) {
                total = total + p.getTotal();
            }
        }
        return total;
    }

    // MÉTODO AGREGADO PARA PANELREPORTES
    public Producto productoMasVendido(String fecha) {
        Producto masVendido = null;
        int maximo = 0;
        for (Producto prod : productos) {
            int unidades = unidadesVendidas(prod, fecha);
            if (unidades > maximo) {
                maximo = unidades;
                masVendido = prod;
            }
        }
        return masVendido;
    }

    public void reporteVentas(String fecha) {
        System.out.println("Total vendido hoy: $" + totalVendido(fecha));
        Producto masVendido = productoMasVendido(fecha);
        if (masVendido != null) {
            int maximo = unidadesVendidas(masVendido, fecha);
            System.out.println("Producto más vendido: " + masVendido.getNombre() + " (" + maximo + " unidades)");
        }
    }
}