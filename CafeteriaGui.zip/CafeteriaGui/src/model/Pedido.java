package model;

import java.util.ArrayList;

public class Pedido {
    public static final double IVA = 0.15;   // porcentaje de IVA

    private int numero;
    private String fecha;
    private ArrayList<Detalle_Pedido> detalles = new ArrayList<>();

    public Pedido(int numero, String fecha) {
        this.numero = numero;
        this.fecha = fecha;
    }

    public int getNumero() { return numero; }
    public String getFecha() { return fecha; }
    public ArrayList<Detalle_Pedido> getDetalles() { return detalles; }

    // Agrega el producto si la cantidad es válida y alcanza el stock
    public boolean agregarProducto(Producto producto, int cantidad) {
        int yaPedido = 0;
        for (Detalle_Pedido d : detalles) {
            if (d.getProducto() == producto) {
                yaPedido = yaPedido + d.getCantidad();
            }
        }
        if (cantidad <= 0 || yaPedido + cantidad > producto.getStock()) {
            return false;
        }
        detalles.add(new Detalle_Pedido(producto, cantidad, producto.getPrecio()));
        return true;
    }

    public double getSubtotal() {
        double subtotal = 0;
        for (Detalle_Pedido d : detalles) {
            subtotal = subtotal + d.getSubtotal();
        }
        return redondear(subtotal);
    }

    public double getIva() {
        return redondear(getSubtotal() * IVA);
    }

    public double getTotal() {
        return redondear(getSubtotal() + getIva());
    }

    // Deja el valor con 2 decimales
    public static double redondear(double valor) {
        return Math.round(valor * 100) / 100.0;
    }
}