package app;

import javax.swing.JOptionPane;
import view.MenuPrincipal;

public class Main {

    public static void main(String[] args) {
        String fecha = JOptionPane.showInputDialog("Fecha de hoy (ejemplo 18/10/2026):");
        if (fecha == null || fecha.trim().equals("")) {
            System.exit(0);   // canceló o la dejó vacía
        }
        new MenuPrincipal(fecha.trim().replace(" ", "")).setVisible(true);
    }
}